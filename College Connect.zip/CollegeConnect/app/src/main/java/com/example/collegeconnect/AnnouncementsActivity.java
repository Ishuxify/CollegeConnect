package com.example.collegeconnect;

import static java.util.Locale.filter;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class AnnouncementsActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private RecyclerView recyclerView;
    private AnnouncementAdapter adapter;
    private FloatingActionButton fabAddAnnouncement;
    private CardView cardProfile;
    private ImageView ivProfileImage;
    private TextView tvUsername, tvUserEmail,etSearch;
    private boolean isAdmin = false;
    List<AnnouncementAdapter.Announcement> fullAnnouncementList; // To store all items


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_announcements);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);  // Status bar transparent banega

            // Optional: Navigation bar bhi transparent karne ke liye
            window.setNavigationBarColor(Color.TRANSPARENT);

            // Fullscreen layout flags lagao, jisse content status bar ke niche jaye
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }

        hideSystemUI();

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Initialize UI components
        recyclerView = findViewById(R.id.recyclerViewAnnouncements);
        cardProfile = findViewById(R.id.cardProfile);
        ivProfileImage = findViewById(R.id.ivProfileImage);
        tvUsername = findViewById(R.id.tvUsername);
        tvUserEmail = findViewById(R.id.tvUserEmail);
        etSearch = findViewById(R.id.etSearch);
        fabAddAnnouncement = findViewById(R.id.fabAddAnnouncement);




// After fetching data from Firebase or wherever:
        fullAnnouncementList = new ArrayList<>(); // Initialize empty list here


// Set search filter logic
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AnnouncementAdapter(this);
        recyclerView.setAdapter(adapter);

        adapter.updateAnnouncements(fullAnnouncementList); // Load into adapter

        // Fetch user profile data
        fetchUserProfile();

        // Check if user is admin
        checkAdminStatus();

        // Fetch announcements
        fetchAnnouncements();

        // Set profile card click listener
        cardProfile.setOnClickListener(v -> {
            startActivity(new Intent(this, StudentDashboardActivity.class));
        });

        // Set FAB click listener
        fabAddAnnouncement.setOnClickListener(v -> {
            if (isAdmin) {
                startActivity(new Intent(this, AdminDashboardActivity.class));
            } else {
                Toast.makeText(this, "Only admins can add announcements", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void filter(String text) {
        List<AnnouncementAdapter.Announcement> filteredList = new ArrayList<>();
        for (AnnouncementAdapter.Announcement item : fullAnnouncementList) {
            if (item.getTitle().toLowerCase().contains(text.toLowerCase()) ||
                    item.getDetails().toLowerCase().contains(text.toLowerCase()) ||
                    item.getCategory().toLowerCase().contains(text.toLowerCase()) ||
                    item.getPriority().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        adapter.filterList(filteredList);
    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
        else {
            showSystemUI();
        }
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN       // Hide status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION  // Hide navigation bar
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void showSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }


    private void fetchUserProfile() {
        if (mAuth.getCurrentUser() == null) {
            Toast.makeText(this, "Please log in to view profile", Toast.LENGTH_SHORT).show();
            return;
        }
        String userId = mAuth.getCurrentUser().getUid();
        mDatabase.child("users").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String name = snapshot.child("name").getValue(String.class);
                    String email = snapshot.child("email").getValue(String.class);
                    String profileImageUrl = snapshot.child("profileImageUrl").getValue(String.class);

                    // Update UI
                    tvUsername.setText(name != null ? name : "Unknown User");
                    tvUserEmail.setText(email != null ? email : "No Email");
                    if (profileImageUrl != null && !profileImageUrl.isEmpty()) {
                        Picasso.get().load(profileImageUrl).placeholder(R.drawable.ic_profile_placeholder).into(ivProfileImage);
                    }
                } else {
                    Toast.makeText(AnnouncementsActivity.this, "User data not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AnnouncementsActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkAdminStatus() {
        if (mAuth.getCurrentUser() == null) {
            fabAddAnnouncement.setVisibility(View.GONE);
            return;
        }
        String userId = mAuth.getCurrentUser().getUid();
        mDatabase.child("users").child(userId).child("role").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String role = snapshot.getValue(String.class);
                isAdmin = "admin".equalsIgnoreCase(role);
                fabAddAnnouncement.setVisibility(isAdmin ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AnnouncementsActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                fabAddAnnouncement.setVisibility(View.GONE);
            }
        });
    }

    private void fetchAnnouncements() {
        mDatabase.child("announcements").addValueEventListener(new ValueEventListener() {


            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<AnnouncementAdapter.Announcement> announcements = new ArrayList<>();
                for (DataSnapshot data : snapshot.getChildren()) {
                    AnnouncementAdapter.Announcement announcement = data.getValue(AnnouncementAdapter.Announcement.class);
                    if (announcement != null) {
                        announcement.announcementId = data.getKey(); // Set ID from Firebase
                        announcements.add(announcement);
                    }
                }


              fullAnnouncementList = new ArrayList<>(announcements);  // ✅ This line is correct
                adapter.updateAnnouncements(fullAnnouncementList);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AnnouncementsActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}