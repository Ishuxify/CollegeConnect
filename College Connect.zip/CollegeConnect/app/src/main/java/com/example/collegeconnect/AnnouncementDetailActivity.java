package com.example.collegeconnect;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AnnouncementDetailActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private TextView tvCategory, tvTitle, tvDetails, tvStartDate, tvEndDate, tvCollegeName, tvLocation, tvPriority;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.activity_announcement_detail);

        // Transparent status and navigation bars
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }

        hideSystemUI();

        // Initialize Firebase
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Initialize UI components
        tvCategory = findViewById(R.id.tv_detail_category);
        tvTitle = findViewById(R.id.tv_detail_title);
        tvDetails = findViewById(R.id.tv_detail_details);
        tvStartDate = findViewById(R.id.tv_detail_start_date);
        tvEndDate = findViewById(R.id.tv_detail_end_date);
        tvCollegeName = findViewById(R.id.tv_detail_college);
        tvLocation = findViewById(R.id.tv_detail_location);
        tvPriority = findViewById(R.id.tv_detail_priority);

        // Get announcement ID from intent
        String announcementId = getIntent().getStringExtra("announcementId");
        if (announcementId == null) {
            Toast.makeText(this, "Invalid announcement ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Fetch announcement details
        fetchAnnouncementDetails(announcementId);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        } else {
            showSystemUI();
        }
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void showSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void fetchAnnouncementDetails(String announcementId) {
        mDatabase.child("announcements").child(announcementId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String title = snapshot.child("title").getValue(String.class);
                    String category = snapshot.child("category").getValue(String.class);
                    String details = snapshot.child("details").getValue(String.class);
                    String startDate = snapshot.child("startDate").getValue(String.class);
                    String endDate = snapshot.child("endDate").getValue(String.class);
                    String collegeName = snapshot.child("collegeName").getValue(String.class);
                    String location = snapshot.child("location").getValue(String.class);
                    String priority = snapshot.child("priority").getValue(String.class);

                    tvCategory.setText(category != null ? "Category: " + category : "Category: N/A");
                    tvTitle.setText(title != null ? title : "No Title");
                    tvDetails.setText(details != null ? "Details: " + details : "Details: N/A");
                    tvStartDate.setText(startDate != null ? "Start Date: " + startDate : "Start Date: N/A");
                    tvEndDate.setText(endDate != null ? "End Date: " + endDate : "End Date: N/A");
                    tvCollegeName.setText(collegeName != null ? "College: " + collegeName : "College: N/A");
                    tvLocation.setText(location != null ? "Location: " + location : "Location: N/A");
                    tvPriority.setText(priority != null ? "Priority: " + priority : "Priority: N/A");
                } else {
                    Toast.makeText(AnnouncementDetailActivity.this, "Announcement not found", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AnnouncementDetailActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}