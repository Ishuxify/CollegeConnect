package com.example.collegeconnect;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AnnouncementAdapter extends RecyclerView.Adapter<AnnouncementAdapter.ViewHolder> {

    private List<Announcement> announcements;
    private Context context;

    public AnnouncementAdapter(Context context) {
        this.context = context;
        this.announcements = new ArrayList<>();
    }

    public void updateAnnouncements(List<Announcement> newAnnouncements) {
        this.announcements.clear();
        this.announcements.addAll(newAnnouncements);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_announcement, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Announcement announcement = announcements.get(position);
        holder.tvCategory.setText(announcement.getCategory());
        holder.tvTitle.setText(announcement.getTitle());
        holder.tvDetails.setText(announcement.getDetails());
        holder.tvDate.setText(announcement.getStartDate());
        holder.tvPriority.setText(announcement.getPriority());

        // Set click listener to open AnnouncementDetailActivity
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, AnnouncementDetailActivity.class);
            intent.putExtra("announcementId", announcement.getAnnouncementId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return announcements.size();
    }

    public void filterList(List<Announcement> filteredList) {
        announcements = filteredList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvCategory, tvTitle, tvDetails, tvDate, tvPriority;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCategory = itemView.findViewById(R.id.tvAnnouncementCategory);
            tvTitle = itemView.findViewById(R.id.tvAnnouncementTitle);
            tvDetails = itemView.findViewById(R.id.tvAnnouncementDetails);
            tvDate = itemView.findViewById(R.id.tvAnnouncementDate);
            tvPriority = itemView.findViewById(R.id.tvAnnouncementPriority);
        }
    }

    // Announcement model class
    public static class Announcement {
        public String announcementId, category, startDate, endDate, collegeName, location, details, priority, adminId;
        public long timestamp;

        public Announcement() {
        }

        public String getAnnouncementId() {
            return announcementId != null ? announcementId : "";
        }

        public String getCategory() {
            return category != null ? category : "Unknown";
        }

        public String getTitle() {
            return collegeName != null ? collegeName : "Untitled";
        }

        public String getDetails() {
            return details != null ? details : "No details available";
        }

        public String getStartDate() {
            return startDate != null ? startDate : "No date";
        }

        public String getEndDate() {
            return endDate != null ? endDate : "No end date";
        }

        public String getCollegeName() {
            return collegeName != null ? collegeName : "Unknown";
        }

        public String getLocation() {
            return location != null ? location : "Unknown";
        }

        public String getPriority() {
            return priority != null ? priority : "Normal";
        }

        public String getAdminId() {
            return adminId != null ? adminId : "";
        }

        public long getTimestamp() {
            return timestamp;
        }
    }
}