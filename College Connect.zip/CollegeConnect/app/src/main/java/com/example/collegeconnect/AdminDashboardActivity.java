package com.example.collegeconnect;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.android.flexbox.FlexboxLayout;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

public class AdminDashboardActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private AutoCompleteTextView categoryInput;
    private TextInputEditText startDateInput, endDateInput, collegeNameInput, locationInput, detailsInput;

    private CardView normalPriorityCard, importantPriorityCard, urgentPriorityCard;
    TextView tvNormalTitle, tvNormalDesc, tvImportantTitle, tvImportantDesc, tvUrgentTitle, tvUrgentDesc;
    private MaterialButton publishButton;
    private String selectedPriority = "Normal";
    private String selectedCategory = "";
    private CardView successMessageCard, adminprofile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        setContentView(R.layout.activity_admin_dashboard);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);  // Status bar transparent banega

            // Optional: Navigation bar bhi transparent karne ke liye
            window.setNavigationBarColor(Color.TRANSPARENT);

            // Fullscreen layout flags lagao, jisse content status bar ke niche jaye
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }



        hideSystemUI();

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Initialize UI components
        categoryInput = findViewById(R.id.actv_form_category);
        startDateInput = findViewById(R.id.et_form_start_date);
        endDateInput = findViewById(R.id.et_form_end_date);
        collegeNameInput = findViewById(R.id.et_form_college_name);
        locationInput = findViewById(R.id.et_form_location);
        adminprofile = findViewById(R.id.cv_view_profile);

        detailsInput = findViewById(R.id.et_form_details);
        normalPriorityCard = findViewById(R.id.cv_priority_normal);
        importantPriorityCard = findViewById(R.id.cv_priority_important);
        urgentPriorityCard = findViewById(R.id.cv_priority_urgent);
        publishButton = findViewById(R.id.btn_publish_announcement);
        successMessageCard = findViewById(R.id.cv_success_message);
        tvNormalTitle = findViewById(R.id.tv_priority_normal_title);
        tvNormalDesc = findViewById(R.id.tv_priority_normal_description);
        tvImportantTitle = findViewById(R.id.tv_priority_important_title);
        tvImportantDesc = findViewById(R.id.tv_priority_important_description);
        tvUrgentTitle = findViewById(R.id.tv_priority_urgent_title);
        tvUrgentDesc = findViewById(R.id.tv_priority_urgent_description);


        // Set up category dropdown
        String[] categories = {"Admission", "Cultural Fest", "Hackathon", "Seminar", "Sports", "Workshop"};
        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(this, R.layout.dropdown_item, categories);
        categoryInput.setAdapter(categoryAdapter);
        categoryInput.setOnItemClickListener((parent, view, position, id) -> {
            selectedCategory = categories[position];
        });
        categoryInput.setOnClickListener(v -> categoryInput.showDropDown());

        // Set up date pickers
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener startDateSetListener = (view, year, month, day) -> {
            calendar.set(year, month, day);
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
            startDateInput.setText(sdf.format(calendar.getTime()));
        };
        DatePickerDialog.OnDateSetListener endDateSetListener = (view, year, month, day) -> {
            calendar.set(year, month, day);
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
            endDateInput.setText(sdf.format(calendar.getTime()));
        };
        startDateInput.setOnClickListener(v -> new DatePickerDialog(
                AdminDashboardActivity.this,
                startDateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show());
        endDateInput.setOnClickListener(v -> new DatePickerDialog(
                AdminDashboardActivity.this,
                endDateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show());



        // Priority selection
        normalPriorityCard.setOnClickListener(v -> selectPriority("Normal", normalPriorityCard));
        importantPriorityCard.setOnClickListener(v -> selectPriority("Important", importantPriorityCard));
        urgentPriorityCard.setOnClickListener(v -> selectPriority("Urgent", urgentPriorityCard));

        // Publish button
        publishButton.setOnClickListener(v -> publishAnnouncement());

        // Save draft and preview buttons (placeholders)
        findViewById(R.id.btn_save_draft).setOnClickListener(v -> Toast.makeText(this, "Save as draft clicked", Toast.LENGTH_SHORT).show());
        findViewById(R.id.btn_preview_announcement).setOnClickListener(v -> Toast.makeText(this, "Preview clicked", Toast.LENGTH_SHORT).show());


        //admin profile navigation.
        adminprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardActivity.this, AdminProfileActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }



    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }

    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN       // Hide status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION  // Hide navigation bar
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void showSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void selectPriority(String priority, CardView selectedCard) {
        normalPriorityCard.setCardBackgroundColor(getResources().getColor(android.R.color.white));
        importantPriorityCard.setCardBackgroundColor(getResources().getColor(R.color.white));
        urgentPriorityCard.setCardBackgroundColor(getResources().getColor(android.R.color.white));
        normalPriorityCard.setCardElevation(2);
        importantPriorityCard.setCardElevation(2);
        urgentPriorityCard.setCardElevation(2);

        // Reset text colors to default
        tvNormalTitle.setTextColor(Color.parseColor("#757575"));
        tvNormalDesc.setTextColor(Color.parseColor("#757575"));
        tvImportantTitle.setTextColor(Color.parseColor("#757575"));
        tvImportantDesc.setTextColor(Color.parseColor("#757575"));
        tvUrgentTitle.setTextColor(Color.parseColor("#757575"));
        tvUrgentDesc.setTextColor(Color.parseColor("#757575"));

        selectedCard.setCardBackgroundColor(getResources().getColor(R.color.purple));
        selectedCard.setCardElevation(6);


        // Set selected text color to white
        if (priority.equals("Normal")) {
            tvNormalTitle.setTextColor(Color.WHITE);
            tvNormalDesc.setTextColor(Color.WHITE);
        } else if (priority.equals("Important")) {
            tvImportantTitle.setTextColor(Color.WHITE);
            tvImportantDesc.setTextColor(Color.WHITE);
        } else if (priority.equals("Urgent")) {
            tvUrgentTitle.setTextColor(Color.WHITE);
            tvUrgentDesc.setTextColor(Color.WHITE);
        }

        selectedPriority = priority;
    }

    private void publishAnnouncement() {
        String category = selectedCategory;
        String startDate = startDateInput.getText().toString().trim();
        String endDate = endDateInput.getText().toString().trim();
        String collegeName = collegeNameInput.getText().toString().trim();
        String location = locationInput.getText().toString().trim();
        String details = detailsInput.getText().toString().trim();

        // Validate inputs
        if (TextUtils.isEmpty(category)) {
            categoryInput.setError("Please select a category");
            return;
        }
        if (TextUtils.isEmpty(startDate)) {
            startDateInput.setError("Start date is required");
            return;
        }
        if (TextUtils.isEmpty(endDate)) {
            endDateInput.setError("End date is required");
            return;
        }
        if (TextUtils.isEmpty(collegeName)) {
            collegeNameInput.setError("College name is required");
            return;
        }
        if (TextUtils.isEmpty(location)) {
            locationInput.setError("Location is required");
            return;
        }
        if (TextUtils.isEmpty(details)) {
            detailsInput.setError("Details are required");
            return;
        }

        // Save to Firebase
        String userId = mAuth.getCurrentUser().getUid();
        String announcementId = mDatabase.child("announcements").push().getKey();
        HashMap<String, Object> announcement = new HashMap<>();
        announcement.put("category", category);
        announcement.put("startDate", startDate);
        announcement.put("endDate", endDate);
        announcement.put("collegeName", collegeName);
        announcement.put("location", location);
        announcement.put("details", details);
        announcement.put("priority", selectedPriority);
        announcement.put("adminId", userId);
        announcement.put("timestamp", System.currentTimeMillis());

        mDatabase.child("announcements").child(announcementId).setValue(announcement)
                .addOnSuccessListener(aVoid -> {
                    successMessageCard.setVisibility(View.VISIBLE);
                    Toast.makeText(this, "Announcement published", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}